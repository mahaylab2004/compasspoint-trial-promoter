require 'rails_helper'

RSpec.describe Importer do
  before do
    @importer = Importer.new
  end
end
