FactoryGirl.define do
  factory :buffer_update do
    buffer_id 'abc'
    status :pending
  end
end