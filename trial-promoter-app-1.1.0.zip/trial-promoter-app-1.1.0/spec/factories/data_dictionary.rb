FactoryGirl.define do
  factory :data_dictionary do
    experiment
  end
end