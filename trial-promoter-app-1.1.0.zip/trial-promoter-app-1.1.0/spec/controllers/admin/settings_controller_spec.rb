require 'rails_helper'

RSpec.describe Admin::SettingsController, type: :controller do

end
