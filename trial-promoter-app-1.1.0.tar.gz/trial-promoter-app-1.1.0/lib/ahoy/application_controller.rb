module Ahoy
  class ApplicationController < ActionController::Base
  end
end