class Ahoy::Store < Ahoy::Stores::ActiveRecordTokenStore
  # customize here
end
