FactoryGirl.define do
  factory :click_meter_tracking_link do
    message
  end
end